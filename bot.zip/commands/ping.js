  
module.exports = (client,msg) =>{
    msg.reply("Pong");
}