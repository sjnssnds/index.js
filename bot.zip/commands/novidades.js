module.exports = (client,msg) =>{
    msg.reply("**Agora todas as Nitro são reservadas! quem for revendedor ganhara Preço de revendedor! Nossa Equipe agradeçe!!**");
}