module.exports = (client,msg) =>{
    msg.reply("**Produtos Ativos**: *Spotify* [ON] *Netflix* [ON] *Amazon Prime*[ON] , *Skins e Acessorios MTA*[ON] Mais Info chame pelo Daddy!");
}